import 'package:flutter/material.dart';
import 'package:datadog_flutter_plugin/datadog_flutter_plugin.dart';
import 'logger.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    // Activamos la vista manualmente para RUM
    DatadogSdk.instance.rum?.startView('home', 'HomeScreen');
    datadogLogger?.info('startView: HomeScreen');
  }

  @override
  void dispose() {
    DatadogSdk.instance.rum?.stopView('home');
    datadogLogger?.info('stopView: HomeScreen');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/foto.png'),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                try {
                  DatadogSdk.instance.rum?.addAction(
                    RumActionType.tap,
                    'Mostrar Mensaje Button',
                    {'message_content': 'Bienvenido'},
                  );

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Bienvenido')),
                  );
                } catch (e, stack) {
                  datadogLogger?.error('Error en Bienvenido: $e');
                  DatadogSdk.instance.rum?.addError(
                    'Error botón Bienvenido',
                    RumErrorSource.custom,
                    stackTrace: stack,
                  );
                }
              },
              child: const Text('Bienvenido'),
            ),
            const SizedBox(height: 20),

            /// 🔴 BOTÓN que lanza error simulado
            ElevatedButton(
              onPressed: () {
                try {
                  // Error simulado: operación inválida
                  String? s;
                  int length = s!.length; // lanza error Null check operator used on a null value

                  // Esto nunca se ejecutará
                  datadogLogger?.info('Esto nunca se verá: $length');
                } catch (e, stack) {
                  // Enviar error a Datadog Logs y RUM
                  datadogLogger?.error('Error Pago', attributes: {
                    'origen': 'Botón Pago',
                    'tipo': e.runtimeType.toString(),
                    'mensaje': e.toString(),
                  });

                  DatadogSdk.instance.rum?.addError(
                    'Error de Pago',
                    RumErrorSource.source,
                    stackTrace: stack,
                  );

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Se generó un error')),
                  );
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Pagar'),
            ),
          ],
        ),
      ),
    );
  }
}
