import 'package:datadog_flutter_plugin/datadog_flutter_plugin.dart';

final datadogLogger = DatadogSdk.instance.logs?.createLogger(
  DatadogLoggerConfiguration(

    service: 'flutter-demo',

  ),
);
