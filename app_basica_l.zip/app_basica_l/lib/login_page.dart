

// login_page.dart
import 'package:flutter/material.dart';
import 'package:datadog_flutter_plugin/datadog_flutter_plugin.dart'; // Import Datadog
import 'home_page.dart';
import 'main.dart'; // Import main.dart to access appLogger

class LoginPage extends StatelessWidget {
  final TextEditingController userController = TextEditingController();
  final TextEditingController passController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: userController,
              decoration: const InputDecoration(
                labelText: 'Usuario',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: passController,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'Contraseña',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                // Log the login attempt using the created appLogger instance
                appLogger.info(
                  'Usuario intenta iniciar sesion',
                  attributes: { // 'attributes' is a named parameter for DatadogLogger methods
                    'username': userController.text,
                    'is_password_empty': passController.text.isEmpty,
                  },
                );

                // Add a RUM Action for the login button press
                // The attributes for DatadogSdk.instance.rum?.addAction are also positional.
                DatadogSdk.instance.rum?.addAction(
                  RumActionType.tap,
                  'Ingresa por Login',
                  { // This is the positional attributes map for addAction
                    'username': userController.text,
                  },
                );

                // Simulate login success and navigate
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                );
              },
              child: const Text('Iniciar sesión'),
            ),
          ],
        ),
      ),
    );
  }
}

