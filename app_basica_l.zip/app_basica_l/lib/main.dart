import 'package:flutter/material.dart';
import 'login_page.dart';
import 'package:datadog_flutter_plugin/datadog_flutter_plugin.dart';


//void main() {
  /*runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: LoginPage(),
  ));*/



late DatadogLogger appLogger;
final logsConfig = DatadogLoggingConfiguration();

final rumConfig = DatadogRumConfiguration(
  applicationId: '9dc08872-de0e-4ee2-a991-29cbe56bccf1',
  telemetrySampleRate: 20,

);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();



  final configuration = DatadogConfiguration(
    clientToken: 'pubfd143dfdcc650b993ca2f5fe1db3b02c',
    env: 'prod',
    site: DatadogSite.us5,
    nativeCrashReportEnabled: true,
    loggingConfiguration: logsConfig, // <-- debe estar presente
    rumConfiguration: rumConfig,
  );

  await DatadogSdk.runApp(
    configuration,
    TrackingConsent.granted,
        () async {
          appLogger = DatadogSdk.instance.logs!.createLogger(
            DatadogLoggerConfiguration(
              name: 'app_logger', // A name for your logger
              service: 'app-observada', // Optional: Service name for this logger

            ),
          );
      runApp(MyApp(datadogSdk: DatadogSdk.instance));
    },
  );
}

class MyApp extends StatelessWidget {
  final DatadogSdk datadogSdk;
  MyApp ({super.key, required this.datadogSdk});
  //const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'App Observada',
      debugShowCheckedModeBanner: false,
      home: LoginPage(),
      navigatorObservers: [
        DatadogNavigationObserver(datadogSdk: datadogSdk),
      ],
    );
  }
}

//}
